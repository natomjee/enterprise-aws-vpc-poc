variable "confluent_cloud_api_key" {
  description = "Confluent Cloud API Key (also referred as Cloud API ID)."
  type        = string
}

variable "confluent_cloud_api_secret" {
  description = "Confluent Cloud API Secret."
  type        = string
  sensitive   = true
}

variable "region" {
  description = "The region of the Azure resources."
  type        = string
}

variable "confluent_environment_id" {
  description = "The ID of the existing Confluent Environment"
  type        = string
}
