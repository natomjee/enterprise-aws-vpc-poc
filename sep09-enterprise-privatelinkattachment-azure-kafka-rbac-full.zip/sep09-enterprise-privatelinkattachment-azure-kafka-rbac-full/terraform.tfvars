# Confluent Cloud API credentials
confluent_cloud_api_key = "54XM37V4UDJKLNDV"
confluent_cloud_api_secret = "cfltnMPdxXL7VYvo5XrRD29Uovzz7nZUxTma1+ii/YWfExRA/KBzUML0xn0OWEww"

# The Azure subscription ID where resources will be created
azure_subscription_id = "e2fc4b68-6dd0-4c89-99c6-d6b16f9a0eba"

# The name of the Azure Resource Group containing your Virtual Network
resource_group_name = "test-vnet-rg"

# The name of the Azure Virtual Network that you want to connect to Confluent Cloud Cluster
# Ensure DNS resolution is properly configured for your VNet
virtual_network_name = "test-vnet"
# The name of the subnet within your VNet for the private endpoint
# This subnet should have private endpoint policies disabled
subnet_name = "test-private-subnet-1"

# The Azure region where your resources are located
# Cross-region Azure Private Link connections are not supported yet.
region = "eastus"

# The Azure location (same as region, used for resource creation)
location = "East US"

# Limitations of Azure Private Link for Enterprise Clusters
# https://docs.confluent.io/cloud/current/networking/azure-privatelink.html
