# Confluent Cloud API credentials
confluent_cloud_api_key = "54XM37V4UDJKLNDV"
confluent_cloud_api_secret = "cfltnMPdxXL7VYvo5XrRD29Uovzz7nZUxTma1+ii/YWfExRA/KBzUML0xn0OWEww"

# The Azure region where your resources are located
region = "eastus"

# The ID of the existing Confluent Environment (replace with your actual environment ID)
confluent_environment_id = "env-9gmkq5"
